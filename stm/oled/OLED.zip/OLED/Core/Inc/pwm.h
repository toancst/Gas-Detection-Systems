// ====== pwm.h ======
#ifndef PWM_H
#define PWM_H

#include <stdint.h>

void PWM_Init(void);
void Update_PWM_From_Mode(uint8_t mode);

#endif
