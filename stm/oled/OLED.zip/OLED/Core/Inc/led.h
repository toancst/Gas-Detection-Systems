// ====== led.h ======
#ifndef LED_H
#define LED_H

#include <stdint.h>

void LED_Init(void);
void LED_Update(uint8_t current_mode);

#endif
